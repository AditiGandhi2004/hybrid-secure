# server.py - simple relay server that never decrypts messages
import socket, threading, json

HOST = '127.0.0.1'
PORT = 65432

clients = {}   # name -> socket
pubkeys = {}   # name -> rsa pub PEM (string)
kem_pubkeys = {}  # name -> kem public (hex string)
lock = threading.Lock()

def handle_client(conn, addr):
    f = conn.makefile(mode='rw', buffering=1)
    try:
        while True:
            line = f.readline()
            if not line:
                break
            obj = json.loads(line.strip())
            typ = obj.get('type')
            if typ == 'register':
                name = obj['name']
                rsa_pub = obj.get('rsa_pub')
                kem_pub = obj.get('kem_pub')
                with lock:
                    clients[name] = conn
                    if rsa_pub:
                        pubkeys[name] = rsa_pub
                    if kem_pub:
                        kem_pubkeys[name] = kem_pub
                resp = {'type':'registered','status':'ok'}
                f.write(json.dumps(resp) + "\n")
                print(f"Registered {name}")
            elif typ == 'send':
                to = obj.get('to')
                with lock:
                    target = clients.get(to)
                if target:
                    try:
                        target.sendall((json.dumps(obj) + '\n').encode())
                        f.write(json.dumps({'type':'sent','status':'ok'}) + '\n')
                    except Exception as e:
                        f.write(json.dumps({'type':'error','error':str(e)}) + '\n')
                else:
                    f.write(json.dumps({'type':'error','error':'target not online'}) + '\n')
            elif typ == 'query_pub':
                qname = obj.get('name')
                with lock:
                    rsa = pubkeys.get(qname)
                    kem = kem_pubkeys.get(qname)
                resp = {'type':'pub_response','rsa_pub': rsa, 'kem_pub': kem}
                f.write(json.dumps(resp) + '\n')
    except Exception as e:
        print('client handler error', e)
    finally:
        conn.close()

def main():
    print('Server starting on', HOST, PORT)
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.bind((HOST, PORT))
    s.listen()
    while True:
        conn, addr = s.accept()
        threading.Thread(target=handle_client, args=(conn, addr), daemon=True).start()

if __name__ == '__main__':
    main()
