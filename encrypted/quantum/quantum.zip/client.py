# client.py - registers RSA pub + KEM pub, sends hybrid-encrypted messages via server
import socket, argparse, json, threading, time
from crypto.hybrid import hybrid_encrypt, hybrid_decrypt, kem_generate_keypair
from Crypto.PublicKey import RSA

HOST = '127.0.0.1'
PORT = 65432

def listen_loop(sock, name):
    f = sock.makefile(mode='rw', buffering=1)
    while True:
        line = f.readline()
        if not line:
            break
        obj = json.loads(line.strip())
        if obj.get('type') == 'send' and obj.get('to') == name:
            sender = obj.get('from')
            package = obj.get('package')
            # ask server for sender rsa pub
            sock.sendall((json.dumps({'type':'query_pub','name': sender}) + '\n').encode())
            resp = f.readline()
            if not resp:
                print('no response for pub query')
                continue
            respj = json.loads(resp.strip())
            sender_rsa_pub = respj.get('rsa_pub').encode()
            try:
                pt = hybrid_decrypt(kem_priv, sender_rsa_pub, package)
                print(f"\n--- New message from {sender} ---\n" + pt.decode() + "\n> ", end='')
            except Exception as e:
                print('Failed to decrypt message:', e)

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--name', required=True)
    parser.add_argument('--peer', required=True)
    parser.add_argument('--pub', required=True)
    parser.add_argument('--priv', required=True)
    args = parser.parse_args()
    name = args.name
    peer = args.peer
    with open(args.pub, 'rb') as f:
        rsa_pub = f.read()
    with open(args.priv, 'rb') as f:
        rsa_priv = f.read()

    # generate KEM keypair (real if installed, else fallback)
    kem_pub, kem_priv = kem_generate_keypair()

    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.connect((HOST, PORT))

    reg = {'type':'register','name': name, 'rsa_pub': rsa_pub.decode(), 'kem_pub': kem_pub.hex() if isinstance(kem_pub, (bytes,bytearray)) else str(kem_pub)}
    s.sendall((json.dumps(reg) + '\n').encode())

    threading.Thread(target=listen_loop, args=(s, name), daemon=True).start()
    time.sleep(0.2)
    print(f"Client {name} ready. Type messages to send to {peer}.\n> ", end='')
    while True:
        try:
            msg = input('> ')
            if not msg:
                continue
            # query recipient pub
            s.sendall((json.dumps({'type':'query_pub','name': peer}) + '\n').encode())
            f = s.makefile(mode='rw', buffering=1)
            resp = f.readline()
            respj = json.loads(resp.strip())
            kem_pub_hex = respj.get('kem_pub')
            if not kem_pub_hex:
                print('Recipient KEM pub not found')
                continue
            recipient_kem_pub = bytes.fromhex(kem_pub_hex)
            package = hybrid_encrypt(recipient_kem_pub, rsa_priv, msg.encode())
            sendobj = {'type':'send','from': name, 'to': peer, 'package': package}
            s.sendall((json.dumps(sendobj) + '\n').encode())
        except KeyboardInterrupt:
            break
